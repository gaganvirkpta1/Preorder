// --- Core deps
const express = require("express");
const dotenv = require("dotenv");
const cors = require("cors");

// --- Shopify API (v11+ paths)
const { shopifyApi, LATEST_API_VERSION } = require("@shopify/shopify-api");
const { MemorySessionStorage } = require("@shopify/shopify-api/session-storage/memory");
const { default: nodeAdapter } = require("@shopify/shopify-api/adapters/node");

// Load env
dotenv.config();

// --- Express app
const app = express();
app.use(cors());
app.use(express.json());

// --- Shopify SDK setup (keep even if you add auth later)
const shopify = shopifyApi({
  apiKey: process.env.SHOPIFY_API_KEY,
  apiSecretKey: process.env.SHOPIFY_API_SECRET,
  scopes: (process.env.SCOPES || "").split(",").map(s => s.trim()).filter(Boolean),
  hostName: (process.env.HOST || "").replace(/https?:\/\//, "").replace(/\/$/, ""),
  apiVersion: LATEST_API_VERSION,
  isEmbeddedApp: true,
  sessionStorage: new MemorySessionStorage(),
  restResources: undefined,
  adapters: { http: nodeAdapter },
});

// --- Health & utility routes
app.get("/", (_req, res) => {
  res.send("✅ Shopify Preorder App Running Successfully!");
});

app.get("/healthz", (_req, res) => res.status(200).send("ok"));

app.get("/check", async (_req, res) => {
  try {
    res.json({ success: true, msg: "Check route working" });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// --- Global error safety
process.on("unhandledRejection", (err) => {
  console.error("UNHANDLED REJECTION:", err);
});
process.on("uncaughtException", (err) => {
  console.error("UNCAUGHT EXCEPTION:", err);
});

// --- IMPORTANT: single listen using Render's PORT
const PORT = process.env.PORT || 10000;
app.listen(PORT, () => {
  console.log(`✅ Server running on port ${PORT}`);
});
