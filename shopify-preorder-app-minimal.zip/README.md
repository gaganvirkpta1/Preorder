# Shopify Preorder App (Minimal, Render-ready)

This is a minimal Node/Express app wired to the Shopify API SDK (v11+) and ready to deploy to **Render**.

## 1) Local run (optional)
```bash
npm install
cp .env.example .env
# Fill values in .env
npm start
```

Open http://localhost:10000

## 2) Deploy to Render
- Create a **Web Service** (Node).
- Build Command: `npm install`
- Start Command: `npm start`
- Environment:
  - `SHOPIFY_API_KEY=...`
  - `SHOPIFY_API_SECRET=...`
  - `SCOPES=read_products,read_customers,write_customers`
  - `HOST=https://<your-render-app>.onrender.com`
  - `SESSION_SECRET=<long-random-string>`

## 3) Health
- `/` should show: "Shopify Preorder App Running Successfully!"
- `/healthz` returns `ok`
- `/check` returns JSON
